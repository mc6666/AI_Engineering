'use client';

import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import PhotoGrid from '@/components/PhotoGrid';
import LightboxOverlay from '@/components/LightboxOverlay';
import EmptyState from '@/components/EmptyState';
import ConfirmDialog from '@/components/ConfirmDialog';
import type { Album, Photo } from '@/types';

export default function AlbumPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [album, setAlbum] = useState<Album | null>(null);
  const [photoList, setPhotoList] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<number | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const scrollY = useRef(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchAlbum = useCallback(async () => {
    const res = await fetch(`/api/albums/${id}`);
    if (!res.ok) { router.push('/'); return; }
    const json = await res.json() as { album: Album; photos: Photo[] };
    setAlbum(json.album);
    setPhotoList(json.photos);
    setLoading(false);
  }, [id, router]);

  useEffect(() => { fetchAlbum(); }, [fetchAlbum]);

  const openLightbox = (index: number) => {
    scrollY.current = window.scrollY;
    setLightboxIndex(index);
  };

  const closeLightbox = () => {
    setLightboxIndex(null);
    requestAnimationFrame(() => window.scrollTo(0, scrollY.current));
  };

  const handleUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploadError(null);
    setUploading(true);

    for (const file of Array.from(files)) {
      const form = new FormData();
      form.append('file', file);
      const res = await fetch(`/api/albums/${id}/photos`, { method: 'POST', body: form });
      const json = await res.json() as { photo?: Photo; message?: string };

      if (!res.ok) {
        setUploadError(json.message ?? 'Failed to upload photo.');
      } else if (json.photo) {
        setPhotoList((prev) => [...prev, json.photo!]);
      }
    }

    setUploading(false);
  };

  const handleDeleteConfirm = async () => {
    if (deleteTarget === null) return;
    await fetch(`/api/photos/${deleteTarget}`, { method: 'DELETE' });
    setPhotoList((prev) => prev.filter((p) => p.id !== deleteTarget));
    setDeleteTarget(null);
  };

  if (loading) return <div className="text-slate-500 text-sm">Loading album…</div>;
  if (!album) return null;

  return (
    <div>
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => router.push('/')}
          className="text-slate-500 hover:text-slate-700"
          aria-label="Back to albums"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-slate-800">{album.name}</h2>
          <p className="text-sm text-slate-500">{album.date} · {photoList.length} {photoList.length === 1 ? 'photo' : 'photos'}</p>
        </div>
        <div className="flex items-center gap-3">
          {uploading && <span className="text-sm text-slate-500">Uploading…</span>}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            + Add Photos
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => handleUpload(e.target.files)}
          />
        </div>
      </div>

      {uploadError && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
          {uploadError}
          <button onClick={() => setUploadError(null)} className="ml-2 underline">Dismiss</button>
        </div>
      )}

      {photoList.length === 0 ? (
        <EmptyState
          title="No photos yet"
          description="Add photos to this album to get started."
          action={
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-5 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
            >
              Add Photos
            </button>
          }
        />
      ) : (
        <PhotoGrid
          photos={photoList}
          onPhotoClick={openLightbox}
          onPhotoDelete={(photoId) => setDeleteTarget(photoId)}
        />
      )}

      {lightboxIndex !== null && (
        <LightboxOverlay
          photos={photoList}
          currentIndex={lightboxIndex}
          onClose={closeLightbox}
          onNavigate={setLightboxIndex}
        />
      )}

      <ConfirmDialog
        isOpen={deleteTarget !== null}
        title="Remove Photo"
        message="Are you sure you want to remove this photo from the album?"
        confirmLabel="Remove"
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
